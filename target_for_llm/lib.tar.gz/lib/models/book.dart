class Book {
  final int? id;
  final String name;
  final String author;
  final String description;
  final String coverImageUrl;
  final String createdAt;
  final String updatedAt;

  Book({
    this.id,
    required this.name,
    required this.author,
    required this.description,
    required this.coverImageUrl,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Book.fromJson(Map<String, dynamic> json) {
    return Book(
      id: json['id'],
      name: json['name'],
      author: json['author'],
      description: json['description'],
      coverImageUrl: json['coverImageUrl'],
      createdAt: json['createdAt'],
      updatedAt: json['updatedAt'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'author': author,
      'description': description,
      'coverImageUrl': coverImageUrl,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }
}
